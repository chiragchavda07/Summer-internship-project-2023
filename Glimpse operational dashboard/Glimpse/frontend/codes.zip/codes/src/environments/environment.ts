export const environment = {
    firebaseConfig: {
        apiKey: "AIzaSyBuvOucgEDkAVoL6l0od3VTGuNavSRJYRI",
        authDomain: "glimse-3fc54.firebaseapp.com",
        projectId: "glimse-3fc54",
        storageBucket: "glimse-3fc54.appspot.com",
        messagingSenderId: "13905312245",
        appId: "1:13905312245:web:0c62f5a6f0cfd2cd2a48bc",
        measurementId: "G-WS6YJ4TF7C"
    }
  };
export const server_url = "http://192.168.0.161:8090";